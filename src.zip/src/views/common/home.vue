<template>
  <div class="mod-home">
  </div>
</template>

<script>
  export default {
  }
</script>

